package ex2;

import com.xeronith.Console;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Ex2 {

    public static void main(String[] args) throws SQLException {
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver").newInstance();
        } catch (Exception ex) {
            Console.writeLine("Error loading driver.");
        }

        Connection connection = null;
        Statement statement = null;
        try {
            connection = DriverManager.getConnection("jdbc:derby://localhost:1527/phdb");
            statement = connection.createStatement();
            
            //CREATE
            //statement.execute("INSERT INTO Contacts (Id, FirstName, LastName, PhoneNumber) VALUES (1, 'John', 'Doe', '+1800...')");
            //Console.writeLine("Record added!");
            
            //UPDATE
            //statement.execute("UPDATE Contacts SET FirstName='Tom', LastName='Johnson', PhoneNumber='+1801...' WHERE ID=10");
            //Console.writeLine("Record updated!");
            
            //DELETE
            //statement.execute("DELETE FROM Contacts WHERE ID=10");
            //Console.writeLine("Record removed!");
            
            ResultSet rs = statement.executeQuery("SELECT * FROM Contacts");
            
            while(rs.next()) {
                Console.write(rs.getString("FirstName"));
                Console.write(" ");
                Console.writeLine(rs.getString("LastName"));
            }
            
            rs.close();
            
        } catch (SQLException ex) {
            Console.writeLine(ex.getMessage());
        } finally {
            statement.close();
            if (!connection.isClosed()) {
                connection.close();
            }
        }
    }
}
