package ex1;

import com.xeronith.Console;
import java.util.Map;

public class UI {

    private static String[] menuItems = {
        "1. Add Product",
        "2. Change Product",
        "3. Delete Product",
        "4. List Products",
        "5. Exit"
    };

    public static void run() {
        while (true) {
            process(menu());
        }
    }

    private static String menu() {
        Console.clear();
        for (String menuItem : menuItems) {
            Console.writeLine(menuItem);
        }
        return Console.readLine();
    }

    private static void process(String choice) {
        switch (choice) {
            case "1": {
                int id = getInt("Id");

                if (Store.containsId(id)) {
                    Console.writeLine("Duplicate Id!");
                } else {
                    String name = getString("Name");
                    int price = getInt("Price");

                    Product product = new Product(id, name, price);
                    Store.add(product);

                    Console.writeLine("Product added.");
                }
            }
            break;
            case "2": {
                int id = getInt("Id");
                Product product = Store.getProductById(id);

                if (product != null) {
                    int price = getInt("New Price");
                    product.setPrice(price);
                    Console.writeLine("Product price changed.");
                } else {
                    Console.writeLine("Product not found!");
                }
            }
            break;
            case "3": {
                int id = getInt("Id");
                Product product = Store.getProductById(id);

                if (product != null) {
                    Store.remove(id);
                    Console.writeLine("Product removed.");
                } else {
                    Console.writeLine("Product not found!");
                }
            }

            break;
            case "4": {

                for (Product product : Store.getProducts().values()) {
                    Console.write(product.getId());
                    Console.write(": ");
                    Console.write(product.getName());
                    Console.write(" -> ");
                    Console.write(product.getPrice());
                    Console.writeLine("$");
                }
            }
            break;
            case "5":
                Console.exit();
                break;
            default:
                Console.writeLine("Invalid choice!");
                break;
        }

        Console.readLine();
    }

    private static String getString(String message) {
        Console.write(message + "? ");
        return Console.readLine();
    }

    private static int getInt(String message) {
        return Integer.parseInt(getString(message));
    }
}
