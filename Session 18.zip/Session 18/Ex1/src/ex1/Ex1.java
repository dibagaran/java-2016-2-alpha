package ex1;

public class Ex1 {

    public static void main(String[] args) {
        UI.run();
    }
}
