package ex1;

//import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

//import java.util.List;
public class Store {
    
    private static Map<Integer, Product> products = new HashMap<>();
    
    public static Map<Integer, Product> getProducts() {
        return products;
    }
    
    public static void add(Product product) {
        products.put(product.getId(), product);
    }
    
    public static boolean containsId(int id) {
        return products.containsKey(id);
    }
    
    public static Product getProductById(int id) {
        if(products.containsKey(id))
            return products.get(id);
        else
            return null;
    }
    
    public static void remove(int id) {
        products.remove(id);
    }
    
    /* private static List<Product> products = new ArrayList<>();
    
    public static void add(Product product) {
        products.add(product);
    }
    
    public static boolean containsId(int id) {
        for (int i = 0; i < products.size(); i++) {
            Product product  = products.get(i);
            if(product.getId() == id)
                return true;
        }
        
        for(Product product : products) {
            if(product.getId() == id)
                return true;
        }
        
        return false;
    }*/
}
