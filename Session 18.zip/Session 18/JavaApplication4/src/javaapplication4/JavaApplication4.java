
package javaapplication4;

import javax.persistence.EntityManager;
import javax.persistence.Persistence;


public class JavaApplication4 {


    public static void main(String[] args) {
        EntityManager em = Persistence.createEntityManagerFactory("JavaApplication4PU").createEntityManager();
        em.getTransaction().begin();
        
        Contact c = new Contact();
        c.setFirstname("John");
        c.setLastname("Doe");
        c.setId(1000);
        c.setPhonenumber("000");
        
        em.persist(c);
        
        em.getTransaction().commit();
    }
    
}
