package com.xeronith;

class Program {

    public static void main(String[] args) {
        String[] database = {
            "book", "ketab",
            "student", "daneshjoo",
            "exam", "azmoon"
        };

        while (true) {
            Console.write("Please enter a word: ");
            String word = Console.readLine();

            boolean found = false;
            
            for (int i = 0; i < database.length; i += 2) {
                if (database[i].equals(word)) {
                    found = true;
                    Console.writeLine(database[i + 1]);
                    break;
                }
                
                if (database[i + 1].equals(word)) {
                    found = true;
                    Console.writeLine(database[i]);
                    break;
                }
            }
            
            if(!found)
                Console.writeLine("Not found!");

        }

        // a b
        // a.equals(b) ... b.equals(a)
    }
}
