package com.xeronith;

class Program {

    public static void main(String[] args) {
        
        int maximumSize = 1000;
        
        String[] names = new String[maximumSize];
        String[] fields = new String[maximumSize];
        int[] ids = new int[maximumSize];
        int current = 0;
        
        while (true) {
            String choice = displayMenu();
            processInput(choice, names, fields, ids, current);
        }
    }
    
    // This method displays the menu
    static String displayMenu() {
        Console.clear();

        String[] menuItems = {"Register Student", "List Students", "Search", "Exit"};
        for (int i = 0; i < menuItems.length; i++) {
            Console.writeLine((i + 1) + ". " + menuItems[i]);
        }

        return Console.readLine();
    }

    // This method processes the user input
    static void processInput(String choice, String[] names, String[] fields, int[] ids, int current) {
        switch (choice) {
            case "1":

                String name = getString("student name");
                int id = getInt("student id");
                String field = getString("student field");
                
                // Saving student data
                names[current] = name;
                fields[current] = field;
                ids[current] =  id;
                
                current++;

                break;
            case "2":
                Console.writeLine("Listing ...");
                break;
            case "3":
                Console.writeLine("Searching ...");
                break;
            case "4":
                Console.exit();
                break;
            default:
                Console.writeLine("Invalid choice! Try again!");
                break;
        }

        Console.readLine();
    }

    static String getString(String param) {
        Console.write("Please enter " + param + ": ");
        return Console.readLine();
    }
    
    static int getInt(String param) {
        Console.write("Please enter " + param + ": ");
        return Console.readInt();
    }
}
