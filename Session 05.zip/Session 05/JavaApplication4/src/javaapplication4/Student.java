package javaapplication4;

public class Student extends Person {
    private int year;

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }
    
    public void study() {
        
    }
    
    public Student(int id) {
        setId(id);
    }
    
    public Student(String firstName, String lastName, int year) {
        setFirstName(firstName);
        setLastName(lastName);
        setYear(year);
    }
}
