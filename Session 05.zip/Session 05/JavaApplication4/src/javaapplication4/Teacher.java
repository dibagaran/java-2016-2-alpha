package javaapplication4;

public class Teacher extends Person {
    private String areaOfExpertise;

    public String getAreaOfExpertise() {
        return areaOfExpertise;
    }

    public void setAreaOfExpertise(String areaOfExpertise) {
        this.areaOfExpertise = areaOfExpertise;
    }
    
    public void teach() {
    }
    
    public Teacher(int id) {
        setId(id);
    }
    
    public Teacher(String firstName, String lastName, String areaOfExpertise) {
        setFirstName(firstName);
        setLastName(lastName);
        setAreaOfExpertise(areaOfExpertise);
    }
}
