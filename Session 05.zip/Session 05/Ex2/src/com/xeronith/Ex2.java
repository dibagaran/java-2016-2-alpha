package com.xeronith;

public class Ex2 extends Game {

    

    public static void main(String[] args) {
        launch();
    }
    
}
