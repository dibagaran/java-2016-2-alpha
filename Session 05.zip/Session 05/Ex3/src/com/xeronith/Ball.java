package com.xeronith;

public class Ball extends Shape {
    private double radius;
    
    public double getRadius() {
        return this.radius;
    }
    
    public Ball(double x, double y, double r, String color) {
        setX(x);
        setY(y);
        this.radius = r;
        setWidth(r * 2);
        setHeight(r * 2);
        setColor(color);
    }
}
