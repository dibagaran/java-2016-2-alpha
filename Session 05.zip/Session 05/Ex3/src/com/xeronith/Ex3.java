package com.xeronith;

public class Ex3 extends Game {
    
    private Ball ball = new Ball(100, 120, 50, "orange");
    private Box box = new Box(200, 100, 40, "lime");
    
    protected void draw() {
        color(ball.getColor());
        circle(ball.getX(), ball.getY(), ball.getRadius());
        
        color(box.getColor());
        square(box.getX(), box.getY(), box.getWidth());
    }

    public static void main(String[] args) {
        launch();
    }

}
