package com.xeronith;

public class Box extends Shape {
    public Box(double x, double y, double size, String color) {
        setX(x);
        setY(y);
        setWidth(size);
        setHeight(size);
        setColor(color);
    }
}

