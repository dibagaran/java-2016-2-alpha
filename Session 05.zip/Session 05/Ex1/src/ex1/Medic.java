package ex1;

public class Medic extends Enemy {
    public void heal() {
        
    }
}
