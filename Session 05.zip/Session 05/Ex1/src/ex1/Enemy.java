package ex1;

public class Enemy {

    private int life;
    private int armor;

    public int getLife() {
        return life;
    }

    public void setLife(int life) {
        this.life = life;
    }

    public int getArmor() {
        return armor;
    }

    public void setArmor(int armor) {
        this.armor = armor;
    }

    public void attack() {
    }

    public void defend() {
    }
}
