package ex1;

public class Ex1 {

    public static void main(String[] args) {

        General g = new General();
        Soldier s = new Soldier();
        Medic m = new Medic();
        
        
    }
    
}
