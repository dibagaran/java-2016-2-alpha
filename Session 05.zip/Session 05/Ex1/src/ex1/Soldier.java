package ex1;

public class Soldier extends Enemy {
    public void throwGrenade() {
    }
    
    
}
