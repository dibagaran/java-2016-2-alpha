package ex1;

public class General extends Enemy {
    public void heavyAttack() {
    }
}
