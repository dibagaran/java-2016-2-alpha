package com.xeronith;

public class UI {

    public static void run() {
        while (true) {
            String choice = menu();
            process(choice);
            Console.readLine();
        }
    }

    private static String menu() {
        Console.clear();
        Console.writeLine("1. Add Code");
        Console.writeLine("2. List Codes");
        Console.writeLine("3. Save");
        Console.writeLine("4. Load");
        Console.writeLine("5. Exit");
        return Console.readLine();
    }

    private static void process(String choice) {
        switch (choice) {
            case "1": {
                Console.write("Code? ");
                byte code = Console.readByte();
                try {
                    CodeList.add(code);
                    Console.writeLine("Code added successfully!");
                } catch (IndexOutOfBoundsException ex) {
                    Console.writeLine("List is full!");
                }
            }
            break;
            case "2": {
                for (int i = 0; i < CodeList.size(); i++) {
                    byte code = CodeList.getCode(i);
                    Console.writeLine(code);
                }
            }
            break;
            case "3":
                try {
                    CodeList.save();
                    Console.writeLine("Saved!");
                } catch (Exception ex) {
                    Console.writeLine(ex.getMessage());
                }
                break;
            case "4":
                try {
                    CodeList.load();
                    Console.writeLine("Loaded!");
                } catch (Exception ex) {
                    Console.writeLine(ex.getMessage());
                }
                break;
            case "5":
                if (CodeList.isChanged()) {
                    Console.writeLine("You have unsaved changes.");
                } else {
                    Console.exit();
                }
                break;
        }
    }
}
