package com.xeronith;

import java.io.FileInputStream;
import java.io.FileOutputStream;

public class CodeList {
    private static byte[] codes = new byte[100];
    private static int current = 0;
    private static boolean changed = false;
    
    public static boolean isChanged() {
        return changed;
    }
    
    
    public static byte getCode(int index) {
        return codes[index];
    }
    
    public static int size() {
        return current;
    }
    
    public static void add(byte code) throws IndexOutOfBoundsException {
        if(current < codes.length) {
            codes[current++] = code;
            changed = true;
        }
        else
            throw new IndexOutOfBoundsException();
    }
    
    public static void save() throws Exception {
        FileOutputStream fout = null;
        try {
            fout = new FileOutputStream("Codes.db", true); //append
            for (int i = 0; i < current; i++) {
                fout.write(codes[i]);
            }
            changed = false;
        }
        finally {
            if(fout != null)
                fout.close();
        }
    }
    
    public static void load() throws Exception {
        FileInputStream fin = null;
        try {
            fin = new FileInputStream("Codes.db");
            current = 0;
            int i = fin.read();
            while(i != -1) {
                add((byte)i);
                i = fin.read();
            }
            changed = false;
        }
        finally {
            if(fin != null)
                fin.close();
        }
    }
}
