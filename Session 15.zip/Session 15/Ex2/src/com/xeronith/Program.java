package com.xeronith;

class Program {

    public static void main(String[] args) throws Exception {
        UI.run();
    }
}
