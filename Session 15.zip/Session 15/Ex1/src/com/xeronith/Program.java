package com.xeronith;

import java.io.*;

class Program {

    public static void main(String[] args) throws Exception {

        /* byte[] values = {45, 78, 89};
        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream("D:/Temp/Out.x");
            fos.write(values);

        } catch (Exception ex) {
            Console.writeLine(ex.getMessage());
        } finally {
            fos.close();
        } */
        FileInputStream fis = null;
        FileOutputStream fos = null;

        try {
            fis = new FileInputStream("D:/Temp/Book.pdf");
            fos = new FileOutputStream("D:/Temp/Book_Java_Copy.pdf");
            int i = fis.read();
            while (i != -1) {
                byte j = (byte) i;
                fos.write(j);
                i = fis.read();
            }
            Console.writeLine("Done!");
        } catch (Exception ex) {
            Console.writeLine(ex.getMessage());
        } finally {
            if (fis != null) {
                fis.close();
            }
            if (fos != null) {
                fos.close();
            }
        }
    }
}
