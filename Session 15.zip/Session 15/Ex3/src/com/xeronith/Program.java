package com.xeronith;

import java.io.*;
import java.nio.CharBuffer;

class Program {

    public static void main(String[] args) throws Exception {
        /*FileWriter fw = null;
        try {
            fw = new FileWriter("D:/Temp/Test.txt");
            fw.write("Hello");
        } catch (Exception ex) {
            Console.writeLine(ex.getMessage());
        } finally {
            if (fw != null) {
                fw.close();
            }
        }*/
        
        FileReader fr = null;
        try {
            fr = new FileReader("D:/Temp/Test.txt");
            char[] buff = new char[1000];
            fr.read(buff);
            System.out.print(buff);
        } catch (Exception ex) {
            Console.writeLine(ex.getMessage());
        } finally {
            if (fr != null) {
                fr.close();
            }
        }
    }
}
