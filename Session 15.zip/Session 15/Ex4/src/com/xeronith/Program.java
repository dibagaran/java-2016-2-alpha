package com.xeronith;

import java.io.*;

class Program {

    public static void main(String[] args) throws Exception {
        /*
        FileOutputStream fos = null;
        DataOutputStream dos = null;

        try {
            fos = new FileOutputStream("D:/Temp/Out.bin");
            dos = new DataOutputStream(fos);
            
            dos.writeInt(2345677);
            dos.writeDouble(4.567);
            dos.writeBoolean(true);
            
        } catch (Exception ex) {
            Console.writeLine(ex.getMessage());
        } finally {
            if (dos != null) {
                dos.close();
            }
            if (fos != null) {
                fos.close();
            }
        }
        */
        
        FileInputStream fis = null;
        DataInputStream dis = null;

        try {
            fis = new FileInputStream("D:/Temp/Out.bin");
            dis = new DataInputStream(fis);
            
            boolean k = dis.readBoolean();
            double j = dis.readDouble();
            int i = dis.readInt();            
            
            Console.writeLine(i);
            Console.writeLine(j);
            Console.writeLine(k);
            
        } catch (Exception ex) {
            Console.writeLine(ex.getMessage());
        } finally {
            if (dis != null) {
                dis.close();
            }
            if (fis != null) {
                fis.close();
            }
        }
    }
}
