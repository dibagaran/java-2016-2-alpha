package com.xeronith;

public class Menu {

    private String[] items = new String[100];
    private int currentItem = 0;
    private int selectedItem = 0;
    private double menuTotalWidth = 400;

    public int getSelectedItem() {
        return selectedItem;
    }

    public int size() {
        return currentItem;
    }

    public void addItem(String item) {
        if (currentItem < items.length) {
            items[currentItem++] = item;
        }
    }

    private double menuItemHeight = 30;
    private double marginLeft = 50;
    private double marginTop = 50;
    private double paddingLeft = 5;
    private double paddingTop = 22;

    public void next() {
        selectedItem = (selectedItem + 1) % currentItem;
    }

    public void prev() {
        selectedItem--;
        if (selectedItem < 0) {
            selectedItem = currentItem - 1;
        }
    }

    public void render(Game game) {

        for (int i = 0; i < currentItem; i++) {
            double x = marginLeft - paddingLeft;
            double y = marginTop - paddingTop + i * menuItemHeight;
            double w = menuTotalWidth;
            double h = menuItemHeight;

            if (pointInRectangle(game.mouseX(), game.mouseY(), x, y, w, h)) {
                selectedItem = i;
            }
        }

        game.color("blue");
        game.rectangle(marginLeft - paddingLeft, marginTop - paddingTop + selectedItem * menuItemHeight, menuTotalWidth, menuItemHeight);
        game.color("white");
        for (int i = 0; i < currentItem; i++) {
            game.text((i + 1) + " " + items[i], marginLeft, marginTop + menuItemHeight * i);
        }

    }

    public boolean pointInRectangle(double px, double py, double rx, double ry, double rw, double rh) {
        return px > rx && px < rx + rw && py > ry && py < ry + rh;
    }
}
