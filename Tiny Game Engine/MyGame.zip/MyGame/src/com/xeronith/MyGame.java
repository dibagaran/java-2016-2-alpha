package com.xeronith;

public class MyGame extends Game {

    private Menu mainMenu = new Menu();
    
    @Override
    protected void setup() {
        mainMenu.addItem("New Game");
        mainMenu.addItem("Load Game");
        mainMenu.addItem("Save Game");
        mainMenu.addItem("Options");
        mainMenu.addItem("Exit");
        
        cursor(false);
    }

    @Override
    protected void mousePressed(int key) {
        switch(key) {
            case 1:
                console("hit!");
                break;
        }
    }

    @Override
    protected void keyPressed(String key) {
        switch (key) {
            case "down":
                mainMenu.next();
                break;
            case "up":
                mainMenu.prev();
                break;
            case "enter":
                switch(mainMenu.getSelectedItem())
                {
                    case 0:
                        console("New Game");
                        break;
                    case 1:
                        console("Load Game");
                        break;
                    case 2:
                        console("Save Game");
                        break;
                    case 3:
                        console("Options");
                        break;
                    case 4:
                        exit();
                        break;
                }
                
                break;
        }
    }

    @Override
    protected void draw() {
       mainMenu.render(this);
       
       image("cursor.png", mouseX(), mouseY());
    }

    public static void main(String[] args) {
        launch();
    }
}
