package com.xeronith;

public class UI {

    public static void run() {
        while (true) {
            String choice = menu();
            process(choice);
            Console.readLine();
        }

    }

    private static String menu() {
        Console.clear();
        Console.writeLine("1. Add Passenger");
        Console.writeLine("2. Add Driver");
        Console.writeLine("3. Add Secretary");
        Console.writeLine("4. Request Service");
        Console.writeLine("5. End Service");
        Console.writeLine("6. Exit");
        return Console.readLine();
    }

    private static void process(String choice) {
        switch (choice) {
            case "1": {
                Console.write("Name: ");
                String name = Console.readLine();
                Console.write("Address: ");
                String address = Console.readLine();
                Console.write("Telephone: ");
                String telephone = Console.readLine();

                try {
                    int code = TaxiService.registerPassenger(name, address, telephone);
                    Console.writeLine("Successfully registered with membership code: " + code);
                } catch (Exception ex) {
                    Console.writeLine(ex.getMessage());
                }
            }
            break;
            case "2": {
                Console.write("Name: ");
                String name = Console.readLine();
                Console.write("Address: ");
                String address = Console.readLine();
                Console.write("Telephone: ");
                String telephone = Console.readLine();
                Console.write("Car: ");
                String car = Console.readLine();

                TaxiService.registerDriver(name, address, telephone, car);

                Console.writeLine("Successfully registered.");
            }
            break;
            case "3":
                Console.writeLine("Adding secretary ...");
                break;
            case "4": {
                Console.write("Membership Code: ");
                int code = Console.readInt();
                Console.write("Name: ");
                String name = Console.readLine();

                if (TaxiService.isPassengerValid(code, name)) {
                    Driver driver = TaxiService.findFirstFreeDriver();
                    if (driver != null) {
                        driver.setBusy(true);
                        Console.writeLine("Driver is on his way!");
                    } else {
                        Console.writeLine("Sorry! No free driver found!");
                    }
                } else {
                    Console.writeLine("Sorry! No registration found with your name.");
                }
            }
            break;
            case "5":
                Console.writeLine("Ending service ...");
                break;
            case "6":
                Console.exit();
                break;
            default:
                Console.writeLine("Invalid choice!");
                break;
        }
    }
}
