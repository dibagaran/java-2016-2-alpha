/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.xeronith;

/**
 *
 * @author Administrator
 */
public class TaxiService {

    private static Passenger[] passengers = new Passenger[100];
    private static int currentPassenger = 0;
    private static Driver[] drivers = new Driver[100];
    private static int currentDriver = 0;

    public static int registerPassenger (String name, String address, String telephone) throws Exception 
    {
        if(currentPassenger < passengers.length)
        {
            Passenger passenger = new Passenger(name, address, telephone);
            passengers[currentPassenger++] = passenger;
            return passenger.getMembershipCode();
        }
        else
        {
            throw new Exception("No more passengers allowed.");
        }
    }

    public static void registerDriver(String name, String address, String telephone, String car) {
        Driver driver = new Driver(name, address, telephone, car);
        drivers[currentDriver++] = driver;
    }

    public static boolean isPassengerValid(int code, String name) {
        for (int i = 0; i < currentPassenger; i++) {
            if (passengers[i].getMembershipCode() == code && passengers[i].getName().equals(name)) {
                return true;
            }
        }

        return false;
    }
    
    public static Driver findFirstFreeDriver() {
        for (int i = 0; i < currentDriver; i++) {
            if(!drivers[i].isBusy())
                return drivers[i];
        }
        
        return null;
    }

    public static void requestService() {

    }

    public static void endService() {

    }
}
