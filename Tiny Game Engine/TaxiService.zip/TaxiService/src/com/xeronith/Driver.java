package com.xeronith;

public class Driver extends Person {
    private String car;

    public String getCar() {
        return car;
    }

    public void setCar(String car) {
        this.car = car;
    }

    public boolean isBusy() {
        return busy;
    }

    public void setBusy(boolean busy) {
        this.busy = busy;
    }
    private boolean busy;
    
    public Driver(String name, String address, String telephone, String car) {
        super(name, address, telephone);
        this.car = car;
        this.busy = false;
    }
}
