package com.xeronith;

class Program {
	public static void main(String[] args) {
            UI.run();
	}
}
