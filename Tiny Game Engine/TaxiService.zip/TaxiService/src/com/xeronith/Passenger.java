/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.xeronith;

/**
 *
 * @author Administrator
 */
public class Passenger extends Person {
    private static int currentMembershipCode = 1;
    private int membershipCode;

    public int getMembershipCode() {
        return membershipCode;
    }
    
    public Passenger(String name, String address, String telephone) {
        super(name, address, telephone);
        membershipCode = currentMembershipCode;
        currentMembershipCode++;
    }
}
