package ex3;

public class Ex3 {

    public static void main(String[] args) {
        Rectangle r = new Rectangle(5, 3);
        
        System.out.println(r.getArea());
    }
}
