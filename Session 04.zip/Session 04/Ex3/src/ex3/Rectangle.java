package ex3;

public class Rectangle {

    private double x;
    private double y;
    private double width;
    private double height;

    public double getX() {
        return x;
    }

    public void setX(double x) {
        if (x > -1000 && x < 1000) {
            this.x = x;
        }
    }

    public double getY() {
        return y;
    }

    public void setY(double y) {
        if (y > -1000 && y < 1000) {
            this.y = y;
        }
    }

    public double getWidth() {
        return width;
    }

    private void setWidth(double width) {
        if (width > 1 && width < 250) {
            this.width = width;
        }
    }

    public double getHeight() {
        return height;
    }

    private void setHeight(double height) {
        if (height > 1 && height < 250) {
            this.height = height;
        }
    }
    
    public Rectangle(double width, double height) {
        setWidth(width);
        setHeight(height);
    }
    
    public double getArea() {
        return this.width * this.height;
    }
}
