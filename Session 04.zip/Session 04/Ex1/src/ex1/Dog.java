package ex1;

public class Dog {

    private double weight;
    private double height;
    private String color;
    private String name;
    private int id;

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        if (weight >= .5 && weight < 200) {
            this.weight = weight;
        }
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

}
