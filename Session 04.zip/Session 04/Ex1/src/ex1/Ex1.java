package ex1;

public class Ex1 {
    public static void main(String[] args) {
        // OOPL : Encapsulation, Inheritance, Polymorphism
        
        // Object = Variabes + Methods
        
        // class -> object (instance)
        
        // Access Modifier (private, public, ..)
        
        // getter, setter
        
        
        Dog dog = new Dog();
        dog.setName("Rex");
    }
}
