package ex2;

public class Ex2 {

    public static void main(String[] args) {
        Person person = new Person("Nikola", "Tesla");
    }

}
