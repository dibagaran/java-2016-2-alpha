package com.xeronith;

public class Store {
    private String name;
    private Product[] products = new Product[1000];
    private int current = 0;
    private boolean isOpen = false;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    public void addProduct(Product product) {
        if(current < products.length)
            products[current++] = product;
        else
            System.out.println("Repository is full!");
    }
    
    public void buy(String productNameToBuy, int countToBuy) {
        if(isOpen) {
           
            boolean found = false;
            for (int i = 0; i < current; i++) {
                Product productInRepository = products[i];
                String productNameInRepository = productInRepository.getName();
                if(productNameInRepository.toUpperCase().equals(productNameToBuy.toUpperCase())) {
                    found = true;
                    
                    int productCountInRepository = productInRepository.getCount();
                    if(countToBuy <= productCountInRepository) {
                        productInRepository.setCount(productCountInRepository - countToBuy);
                        double total = countToBuy * productInRepository.getPrice();
                        System.out.println("Thanks for your purchase. Your total is: " + total);
                    }
                    else
                        System.out.println("Sorry! We don't have enough of this product in our stock.");
                    
                    break;
                }
            }
            
            if(!found)
                System.out.println("Sorry! We don't have this product in stock.");
        }
        else
            System.out.println("Sorry! The store is closed!");
        
    }
    
    public void open() {
        isOpen= true;
    }
    
    public void close() {
        isOpen = false;
    }
}
