package com.xeronith;

class Program {

    public static void main(String[] args) {
        Store store = new Store();
        store.setName("Hyperstar");
        
        Product product1 = new Product();
        product1.setName("PS4");
        product1.setPrice(400);
        product1.setCount(10);
        
        Product product2 = new Product();
        product2.setName("Xbox");
        product2.setPrice(300);
        product2.setCount(15);
        
        store.addProduct(product1);
        store.addProduct(product2);
        
        store.open();
        
        store.buy("PS4", 3);
        
        store.close();
        
        store.buy("PS4", 7);
    }
}
